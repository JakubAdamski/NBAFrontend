import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useAuth } from './components/AuthContext';
import Demo from './components/Demo';
import Login from './components/Login';
import Registration from './components/Registration';
import NotFound from './components/NotFound';

function App() {
  const auth = useAuth();

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/rejestracja" element={<Registration />} />
        {auth.isAuthenticated ? (
          // Tylko zalogowani użytkownicy mają dostęp do Demo
          <Route path="/stronaglowna" element={<Demo />} />
        ) : (
          // Wyświetlanie 404 dla niezalogowanych użytkowników próbujących uzyskać dostęp do Demo
          <Route path="/stronaglowna" element={<NotFound />} />
        )}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
