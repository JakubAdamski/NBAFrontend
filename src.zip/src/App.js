import { BrowserRouter, Routes, Route } from 'react-router-dom';
import"../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Demo from './components/Pages/Home/Demo';
import Login from './components/Login/Login';
import Registration from './components/Registration/Registration';
import AddNews from './components/Pages/News/Addnews';
import Navbar from './components/Navbar/Navbar';
import Games from './components/Pages/Home/Games'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useAuth } from './components/Auth/AuthContext';
import { useEffect } from 'react';
import { setupAxios } from './components/Auth/setupAxios';
import MUser from './components/Pages/User/MUser';
import Logout from './components/Login/Logout';

const queryClient = new QueryClient();

function App() {

  const {me,user} = useAuth();
    console.log(user)

  useEffect(() => {
      const token = localStorage.getItem("token");
      setupAxios(token);
      if (token) {
          me(token);
     }
  }, []);

  return (
       <QueryClientProvider client={queryClient}>
      <div className="App">
        <Navbar />
          <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/rejestracja" element={<Registration />} />
          <Route path="/stronaglowna" element={<Demo />} />
          <Route path='/dodajnews' element={<AddNews/>} />
          <Route path='/mecze' element={<Games/>} />
          <Route path='/users' element={<MUser/>} />
          <Route path='/logout' element={<Logout/>} />
        </Routes>
        </div>
      </QueryClientProvider>
    );
}

export default App;
