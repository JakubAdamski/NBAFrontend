import React from 'react';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';

function Demo() {
   const { isAuthenticated} = useAuth();
   const navigate = useNavigate();

   if (!isAuthenticated) {
      navigate('/');
   }

   return (
      <div>
      <Navbar/>
      </div>
   );
}

export default Demo;

