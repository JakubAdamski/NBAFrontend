import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [authState, setAuthState] = useState({
        isAuthenticated: false,
        token: null,
    });

    useEffect(() => {
        const storedToken = localStorage.getItem('authToken');
        console.log('Loaded token from localStorage:', storedToken); // Dodanie debugowania
        if (storedToken) {
            setAuthState({ isAuthenticated: true, token: storedToken });
        }
    }, []);

    const login = (token) => {
        setAuthState({ isAuthenticated: true, token: token });
        localStorage.setItem('authToken', token);
        console.log('Token saved to localStorage:', token); // Dodanie debugowania
    };

    const logout = () => {
        setAuthState({ isAuthenticated: false, token: null });
        localStorage.removeItem('authToken');
    };

    const authValue = {
        isAuthenticated: authState.isAuthenticated,
        token: authState.token,
        login: login,
        logout: logout,
    };

    return <AuthContext.Provider value={authValue}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
